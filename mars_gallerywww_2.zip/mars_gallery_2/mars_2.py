from flask import Flask, url_for, request, redirect, render_template
import os

app = Flask(__name__)


@app.route('/carousel', methods=['POST', 'GET'])
def carousel():
    pictures = os.listdir('static/img')
    if request.method == 'GET':
        return render_template('carousel.html', pictures=pictures)
    if request.method == 'POST':
        f = request.files['file']
        with open(f'static/img/{len(pictures) + 1}.jpg', 'wb') as file:
            file.write(f.read())
        return redirect('/carousel')

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
